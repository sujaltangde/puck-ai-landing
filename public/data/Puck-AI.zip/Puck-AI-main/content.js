(async () => {
  // Import API key from external file
  const { OPEN_AI_API_KEY } = await import(chrome.runtime.getURL("api_key.js"));
  const API_KEY = OPEN_AI_API_KEY;

  // State management
  let isProcessing = false;
  let inputTimeout;

  // Extract Gmail thread ID from URL
  function getThreadIdFromUrl(url) {
    const urlObj = new URL(url);
    
    if (urlObj.hostname !== "mail.google.com") {
      return null;
    }

    const threadId = urlObj.hash.split("/")[1];
    return threadId || null;
  }

  // Parse GitHub issue/PR data from URL
  function getGitHubIssueDataFromUrl(url) {
    const urlObj = new URL(url);
    
    if (urlObj.hostname !== "github.com") {
      return null;
    }

    const pathParts = urlObj.pathname.split("/");
    const isIssueOrPR = pathParts[3] === "issues" || pathParts[3] === "pull";
    
    if (pathParts.length >= 5 && isIssueOrPR) {
      return {
        owner: pathParts[1],
        repo: pathParts[2],
        type: pathParts[3],
        number: pathParts[4],
      };
    }
    
    return null;
  }

  // Parse Slack conversation data from URL
  function getSlackConversationDataFromUrl(url) {
    const urlObj = new URL(url);
    
    if (urlObj.hostname !== "app.slack.com") {
      return null;
    }

    const pathParts = urlObj.pathname.split("/");
    
    if (pathParts.length >= 4 && pathParts[1] === "client") {
      const channelId = pathParts[3];
      
      return {
        teamId: pathParts[2],
        channelId,
        isDM: channelId.startsWith("D"),
        isChannel: channelId.startsWith("C"),
        isGroup: channelId.startsWith("G"),
      };
    }
    
    return null;
  }

  // Extract GitHub issue data from DOM
  function extractGitHubIssueContentFromDOM() {
    try {
      const issueData = {
        title: "",
        description: "",
        comments: [],
        labels: [],
        assignees: [],
        milestone: "",
        state: "",
      };

      // Get title
      const titleEl = document.querySelector('[data-testid="issue-title"] h1, .gh-header-title h1, .js-issue-title');
      if (titleEl) {
        issueData.title = titleEl.textContent.trim();
      }

      // Get description
      const descEl = document.querySelector('.comment-body, .markdown-body, [data-testid="issue-description"]');
      if (descEl) {
        issueData.description = descEl.textContent.trim();
      }

      // Get state
      const stateEl = document.querySelector('.State, .gh-header-meta .State, [data-testid="issue-state"]');
      if (stateEl) {
        issueData.state = stateEl.textContent.trim();
      }

      // Get labels
      document.querySelectorAll(".IssueLabel, .gh-header-meta .IssueLabel").forEach(label => {
        issueData.labels.push(label.textContent.trim());
      });

      // Get assignees
      document.querySelectorAll(".assignee, .gh-header-meta .assignee").forEach(assignee => {
        issueData.assignees.push(assignee.textContent.trim());
      });

      // Get milestone
      const milestoneEl = document.querySelector(".milestone, .gh-header-meta .milestone");
      if (milestoneEl) {
        issueData.milestone = milestoneEl.textContent.trim();
      }

      // Get comments
      document.querySelectorAll(".timeline-comment, .js-comment").forEach((comment, index) => {
        const authorEl = comment.querySelector(".author, .timeline-comment-header .author");
        const bodyEl = comment.querySelector(".comment-body, .markdown-body");

        if (authorEl && bodyEl) {
          issueData.comments.push({
            author: authorEl.textContent.trim(),
            body: bodyEl.textContent.trim(),
            index: index + 1,
          });
        }
      });

      return issueData;
    } catch (error) {
      console.error("Error extracting GitHub issue content:", error);
      return null;
    }
  }

  // Extract Slack conversation data from DOM
  function extractSlackConversationContentFromDOM() {
    try {
      const conversationData = {
        channelName: "",
        messages: [],
        participants: [],
        threadInfo: null,
      };

      // Get channel name
      const channelEl = document.querySelector('[data-testid="channel-header"], .p-channel_sidebar__channel, .c-message__sender, .c-message_kit__sender');
      if (channelEl) {
        conversationData.channelName = channelEl.textContent.trim();
      }

      // Get messages
      const messageEls = document.querySelectorAll('[data-testid="message-container"], .c-message, .c-message_kit__message, .c-message_kit__gutter');

      messageEls.forEach((messageEl) => {
        try {
          const senderEl = messageEl.querySelector('.c-message__sender, .c-message_kit__sender, [data-testid="message-sender"]');
          const timestampEl = messageEl.querySelector('.c-message__timestamp, .c-message_kit__timestamp, [data-testid="message-timestamp"]');
          const contentEl = messageEl.querySelector('.c-message__body, .c-message_kit__message, .c-message_kit__blocks, [data-testid="message-content"]');

          const sender = senderEl ? senderEl.textContent.trim() : "Unknown User";
          const timestamp = timestampEl ? timestampEl.textContent.trim() : "";
          let content = "";

          if (contentEl) {
            content = contentEl.textContent.trim().replace(/\s+/g, " ").substring(0, 500);
          }

          // Get reactions
          const reactions = [];
          messageEl.querySelectorAll('.c-message__reactions, .c-message_kit__reactions, [data-testid="message-reactions"]').forEach(reaction => {
            const reactionText = reaction.textContent.trim();
            if (reactionText) {
              reactions.push(reactionText);
            }
          });

          if (content && sender) {
            conversationData.messages.push({
              sender,
              timestamp,
              content,
              reactions: reactions.length > 0 ? reactions.join(", ") : "",
              index: conversationData.messages.length + 1,
            });

            if (!conversationData.participants.includes(sender)) {
              conversationData.participants.push(sender);
            }
          }
        } catch (error) {
          console.error("Error extracting message:", error);
        }
      });

      // Fallback: try to get any conversation content
      if (conversationData.messages.length === 0) {
        const mainContent = document.querySelector('[data-testid="conversation-container"], .c-messages_container, .c-message_pane');
        if (mainContent) {
          const textContent = mainContent.textContent.trim();
          if (textContent) {
            const lines = textContent.split("\n").filter(line => line.trim().length > 0);
            lines.forEach((line, index) => {
              if (line.length > 10 && index < 20) {
                conversationData.messages.push({
                  sender: "User",
                  timestamp: "",
                  content: line.substring(0, 200),
                  reactions: "",
                  index: index + 1,
                });
              }
            });
          }
        }
      }

      // Check for thread context
      const threadEl = document.querySelector('[data-testid="thread-indicator"], .c-thread_indicator, .c-message_kit__thread_indicator');
      if (threadEl) {
        conversationData.threadInfo = {
          isThread: true,
          threadTitle: threadEl.textContent.trim() || "Thread",
        };
      }

      return conversationData;
    } catch (error) {
      console.error("Error extracting Slack conversation:", error);
      return null;
    }
  }

  // Fetch GitHub issue data
  async function fetchCurrentGitHubIssue() {
    if (window.location.hostname !== "github.com") {
      return null;
    }

    try {
      const issueData = getGitHubIssueDataFromUrl(window.location.href);
      if (!issueData) return null;

      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const content = extractGitHubIssueContentFromDOM();
      if (!content) return null;

      return { success: true, ...issueData, content };
    } catch (error) {
      console.error("Error fetching GitHub issue:", error);
      return null;
    }
  }

  // Fetch Slack conversation data
  async function fetchCurrentSlackConversation() {
    if (window.location.hostname !== "app.slack.com") {
      return null;
    }

    try {
      const conversationData = getSlackConversationDataFromUrl(window.location.href);
      if (!conversationData) return null;

      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const content = extractSlackConversationContentFromDOM();
      if (!content) return null;

      return { success: true, ...conversationData, content };
    } catch (error) {
      console.error("Error fetching Slack conversation:", error);
      return null;
    }
  }

  // Format GitHub context for AI
  function formatGitHubContext(issueData) {
    if (!issueData?.content) return "";

    const content = issueData.content;
    let context = `\n\n=== GITHUB ISSUE CONTEXT ===\n`;
    context += `Repository: ${issueData.owner}/${issueData.repo}\n`;
    context += `Issue Type: ${issueData.type}\n`;
    context += `Issue Number: #${issueData.number}\n`;
    context += `State: ${content.state}\n`;
    context += `Title: ${content.title}\n`;

    if (content.labels.length > 0) {
      context += `Labels: ${content.labels.join(", ")}\n`;
    }

    if (content.assignees.length > 0) {
      context += `Assignees: ${content.assignees.join(", ")}\n`;
    }

    if (content.milestone) {
      context += `Milestone: ${content.milestone}\n`;
    }

    context += `\nDESCRIPTION:\n${content.description}\n`;

    if (content.comments.length > 0) {
      context += `\nCOMMENTS (${content.comments.length}):\n`;
      content.comments.forEach(comment => {
        context += `\n--- Comment ${comment.index} by ${comment.author} ---\n`;
        context += `${comment.body}\n`;
      });
    }

    context += `\n=== END GITHUB CONTEXT ===\n\n`;
    return context;
  }

  // Format Slack context for AI
  function formatSlackContext(conversationData) {
    if (!conversationData?.content) return "";

    const content = conversationData.content;
    let context = `\n\n=== SLACK CONVERSATION CONTEXT ===\n`;

    if (conversationData.isDM) {
      context += `Conversation Type: Direct Message\n`;
    } else if (conversationData.isChannel) {
      context += `Conversation Type: Channel\n`;
    } else if (conversationData.isGroup) {
      context += `Conversation Type: Private Group\n`;
    }

    context += `Channel/Thread: ${content.channelName || "Unknown"}\n`;

    if (content.threadInfo?.isThread) {
      context += `Thread: ${content.threadInfo.threadTitle}\n`;
    }

    if (content.participants.length > 0) {
      context += `Participants: ${content.participants.join(", ")}\n`;
    }

    context += `Number of messages: ${content.messages.length}\n\n`;

    if (content.messages.length > 0) {
      context += `RECENT MESSAGES:\n`;
      const recentMessages = content.messages.slice(-10);
      recentMessages.forEach(message => {
        context += `\n--- Message ${message.index} ---\n`;
        context += `From: ${message.sender}\n`;
        if (message.timestamp) {
          context += `Time: ${message.timestamp}\n`;
        }
        context += `Content: ${message.content}\n`;
        if (message.reactions) {
          context += `Reactions: ${message.reactions}\n`;
        }
      });
    }

    context += `\n=== END SLACK CONTEXT ===\n\n`;
    return context;
  }

  // Function to get current YouTube video data from URL
  function getYouTubeVideoDataFromUrl(url) {
    const urlObj = new URL(url);
    if (
      urlObj.hostname === "www.youtube.com" ||
      urlObj.hostname === "youtube.com"
    ) {
      const videoId = urlObj.searchParams.get("v");
      if (videoId) {
        return {
          videoId,
          isCommentSection:
            urlObj.hash.includes("#comment") || urlObj.searchParams.get("lc"),
          commentId: urlObj.searchParams.get("lc") || null,
        };
      }
    }
    return null;
  }

  // Function to extract YouTube video content from DOM
  function extractYouTubeVideoContentFromDOM() {
    try {
      const videoData = {
        title: "",
        description: "",
        channelName: "",
        viewCount: "",
        publishDate: "",
        duration: "",
        likes: "",
        comments: [],
      };

      // Extract video title
      const titleElement = document.querySelector(
        "h1.ytd-video-primary-info-renderer, h1.ytd-watch-metadata, #title h1, .title.style-scope.ytd-video-primary-info-renderer"
      );
      if (titleElement) {
        videoData.title = titleElement.textContent.trim();
      }

      // Extract video description
      const descriptionElement = document.querySelector(
        "#description #description-text, .ytd-video-secondary-info-renderer #description, #meta-contents #description"
      );
      if (descriptionElement) {
        videoData.description = descriptionElement.textContent.trim();
        // Limit description length
        videoData.description = videoData.description.substring(0, 1000);
      }

      // Extract channel name
      const channelElement = document.querySelector(
        "#channel-name a, .ytd-channel-name a, #owner-name a"
      );
      if (channelElement) {
        videoData.channelName = channelElement.textContent.trim();
      }

      // Extract view count
      const viewElement = document.querySelector(
        "#count .view-count, .ytd-video-view-count-renderer, #metadata-line span:first-child"
      );
      if (viewElement) {
        videoData.viewCount = viewElement.textContent.trim();
      }

      // Extract publish date
      const dateElement = document.querySelector(
        "#metadata-line span:last-child, .ytd-video-primary-info-renderer #metadata-line span:last-child"
      );
      if (dateElement) {
        videoData.publishDate = dateElement.textContent.trim();
      }

      // Extract likes count
      const likesElement = document.querySelector(
        "#top-level-buttons-computed ytd-toggle-button-renderer:first-child #text, #segmented-like-button #text"
      );
      if (likesElement) {
        videoData.likes = likesElement.textContent.trim();
      }

      return videoData;
    } catch (error) {
      console.error("Error extracting YouTube video content from DOM:", error);
      return null;
    }
  }

  // Function to extract YouTube comment context from DOM
  function extractYouTubeCommentContextFromDOM() {
    try {
      const commentData = {
        parentComment: null,
        replyChain: [],
        currentCommentId: null,
      };

      // Check if we're in a reply context by looking for reply indicators
      const replyIndicator = document.querySelector(
        '.ytd-comment-renderer[data-is-reply="true"], .ytd-comment-thread-renderer .ytd-comment-renderer'
      );

      if (replyIndicator) {
        // Find the parent comment (the comment being replied to)
        const parentCommentElement = replyIndicator
          .closest(".ytd-comment-thread-renderer")
          ?.querySelector(".ytd-comment-renderer:first-child");

        if (parentCommentElement) {
          const parentAuthor = parentCommentElement.querySelector(
            "#author-text, .ytd-comment-renderer #author-text"
          );
          const parentContent = parentCommentElement.querySelector(
            "#content-text, .ytd-comment-renderer #content-text"
          );
          const parentTime = parentCommentElement.querySelector(
            "#header-author, .ytd-comment-renderer #header-author"
          );

          if (parentAuthor && parentContent) {
            commentData.parentComment = {
              author: parentAuthor.textContent.trim(),
              content: parentContent.textContent.trim(),
              time: parentTime ? parentTime.textContent.trim() : "",
              likes: "",
            };

            // Extract likes for parent comment
            const parentLikes = parentCommentElement.querySelector(
              "#vote-count-middle, .ytd-comment-renderer #vote-count-middle"
            );
            if (parentLikes) {
              commentData.parentComment.likes = parentLikes.textContent.trim();
            }
          }
        }

        // Find the reply chain (other replies to the same parent)
        const replyElements = document.querySelectorAll(
          ".ytd-comment-thread-renderer .ytd-comment-renderer:not(:first-child)"
        );

        replyElements.forEach((replyElement, index) => {
          const replyAuthor = replyElement.querySelector(
            "#author-text, .ytd-comment-renderer #author-text"
          );
          const replyContent = replyElement.querySelector(
            "#content-text, .ytd-comment-renderer #content-text"
          );
          const replyTime = replyElement.querySelector(
            "#header-author, .ytd-comment-renderer #header-author"
          );

          if (replyAuthor && replyContent) {
            commentData.replyChain.push({
              author: replyAuthor.textContent.trim(),
              content: replyContent.textContent.trim(),
              time: replyTime ? replyTime.textContent.trim() : "",
              likes: "",
              index: index + 1,
            });

            // Extract likes for reply
            const replyLikes = replyElement.querySelector(
              "#vote-count-middle, .ytd-comment-renderer #vote-count-middle"
            );
            if (replyLikes) {
              commentData.replyChain[commentData.replyChain.length - 1].likes =
                replyLikes.textContent.trim();
            }
          }
        });
      }

      // Try to get current comment ID from URL or active element
      const urlParams = new URLSearchParams(window.location.search);
      const commentId = urlParams.get("lc");
      if (commentId) {
        commentData.currentCommentId = commentId;
      }

      return commentData;
    } catch (error) {
      console.error(
        "Error extracting YouTube comment context from DOM:",
        error
      );
      return null;
    }
  }

  // Function to fetch current YouTube data from DOM
  async function fetchCurrentYouTubeData() {
    if (
      window.location.hostname !== "www.youtube.com" &&
      window.location.hostname !== "youtube.com"
    ) {
      return null;
    }

    try {
      const videoData = getYouTubeVideoDataFromUrl(window.location.href);
      if (!videoData) {
        return null;
      }

      // Wait a bit for YouTube to load the content
      await new Promise((resolve) => setTimeout(resolve, 2000));

      const videoContent = extractYouTubeVideoContentFromDOM();
      const commentContext = extractYouTubeCommentContextFromDOM();

      if (!videoContent) {
        return null;
      }

      const result = {
        success: true,
        ...videoData,
        videoContent,
        commentContext,
      };

      return result;
    } catch (error) {
      console.error("Error fetching YouTube data from DOM:", error);
      return null;
    }
  }

  // Function to format YouTube context for AI
  function formatYouTubeContext(youtubeData) {
    if (!youtubeData || !youtubeData.videoContent) {
      return "";
    }

    const video = youtubeData.videoContent;
    const comment = youtubeData.commentContext;

    let context = `\n\n=== YOUTUBE VIDEO CONTEXT ===\n`;
    context += `Video Title: ${video.title}\n`;
    context += `Channel: ${video.channelName}\n`;

    if (video.viewCount) {
      context += `Views: ${video.viewCount}\n`;
    }

    if (video.publishDate) {
      context += `Published: ${video.publishDate}\n`;
    }

    if (video.likes) {
      context += `Likes: ${video.likes}\n`;
    }

    context += `\nVIDEO DESCRIPTION:\n${video.description}\n`;

    // Add comment context if we're in a reply
    if (comment && comment.parentComment) {
      context += `\n=== COMMENT CONTEXT ===\n`;
      context += `Replying to: ${comment.parentComment.author}\n`;
      context += `Original Comment: ${comment.parentComment.content}\n`;

      if (comment.parentComment.time) {
        context += `Posted: ${comment.parentComment.time}\n`;
      }

      if (comment.parentComment.likes) {
        context += `Likes: ${comment.parentComment.likes}\n`;
      }

      // Add reply chain context
      if (comment.replyChain.length > 0) {
        context += `\nREPLY CHAIN (${comment.replyChain.length} replies):\n`;
        comment.replyChain.forEach((reply) => {
          context += `\n--- Reply ${reply.index} by ${reply.author} ---\n`;
          context += `Content: ${reply.content}\n`;
          if (reply.time) {
            context += `Time: ${reply.time}\n`;
          }
          if (reply.likes) {
            context += `Likes: ${reply.likes}\n`;
          }
        });
      }
    }

    context += `\n=== END YOUTUBE CONTEXT ===\n\n`;

    return context;
  }

  // Function to get current Facebook post data from URL
  function getFacebookPostDataFromUrl(url) {
    const urlObj = new URL(url);
    if (
      urlObj.hostname === "www.facebook.com" ||
      urlObj.hostname === "facebook.com" ||
      urlObj.hostname === "m.facebook.com"
    ) {
      // Facebook URLs can be complex, try to extract post ID
      const pathParts = urlObj.pathname.split("/");
      const postId =
        urlObj.searchParams.get("story_fbid") ||
        urlObj.searchParams.get("fbid") ||
        pathParts.find((part) => /^\d+$/.test(part));

      if (postId) {
        return {
          postId,
          isPost: true,
          isComment:
            urlObj.hash.includes("#comment") ||
            urlObj.searchParams.get("comment_id"),
          commentId: urlObj.searchParams.get("comment_id") || null,
        };
      }
    }
    return null;
  }

  // Function to extract Facebook post content from DOM
  function extractFacebookPostContentFromDOM() {
    try {
      const postData = {
        author: "",
        content: "",
        timestamp: "",
        likes: "",
        shares: "",
        comments: [],
        isCommentReply: false,
        parentComment: null,
      };

      // Check if we're in a comment reply context
      const replyInput = document.querySelector(
        '[data-testid="comment-composer"], [aria-label*="Write a comment"], [placeholder*="Write a comment"], [contenteditable="true"][data-testid*="comment"]'
      );

      if (replyInput) {
        // Try to find the comment being replied to
        const commentThread = replyInput.closest(
          '[data-testid*="comment"], .comment, [role="article"]'
        );
        if (commentThread) {
          const parentCommentElement = commentThread.querySelector(
            '[data-testid*="comment"], .comment'
          );
          if (parentCommentElement) {
            const parentAuthor = parentCommentElement.querySelector(
              '[data-testid="comment-author"], .comment-author, a[role="link"]'
            );
            const parentContent = parentCommentElement.querySelector(
              '[data-testid="comment-content"], .comment-content, [dir="auto"]'
            );

            if (parentAuthor && parentContent) {
              postData.isCommentReply = true;
              postData.parentComment = {
                author: parentAuthor.textContent.trim(),
                content: parentContent.textContent.trim(),
                timestamp: "",
                likes: "",
              };

              // Extract timestamp and likes for parent comment
              const parentTime = parentCommentElement.querySelector(
                '[data-testid="comment-timestamp"], .comment-timestamp, time'
              );
              const parentLikes = parentCommentElement.querySelector(
                '[data-testid="comment-likes"], .comment-likes'
              );

              if (parentTime) {
                postData.parentComment.timestamp =
                  parentTime.textContent.trim();
              }
              if (parentLikes) {
                postData.parentComment.likes = parentLikes.textContent.trim();
              }
            }
          }
        }
      }

      // Extract main post content
      const postElement = document.querySelector(
        '[data-testid="post_message"], [data-testid="post-content"], [role="article"], .post, [data-testid*="post"]'
      );

      if (postElement) {
        // Extract post author
        const authorElement = postElement.querySelector(
          '[data-testid="post-author"], .post-author, a[role="link"], [data-testid*="author"]'
        );
        if (authorElement) {
          postData.author = authorElement.textContent.trim();
        }

        // Extract post content
        const contentElement = postElement.querySelector(
          '[data-testid="post_message"], [data-testid="post-content"], [dir="auto"], .post-content, [data-testid*="content"]'
        );
        if (contentElement) {
          postData.content = contentElement.textContent.trim();
          // Limit content length
          postData.content = postData.content.substring(0, 1000);
        }

        // Extract post timestamp
        const timeElement = postElement.querySelector(
          '[data-testid="post-timestamp"], .post-timestamp, time, [data-testid*="timestamp"]'
        );
        if (timeElement) {
          postData.timestamp = timeElement.textContent.trim();
        }

        // Extract engagement metrics
        const likesElement = postElement.querySelector(
          '[data-testid="post-likes"], .post-likes, [data-testid*="likes"]'
        );
        if (likesElement) {
          postData.likes = likesElement.textContent.trim();
        }

        const sharesElement = postElement.querySelector(
          '[data-testid="post-shares"], .post-shares, [data-testid*="shares"]'
        );
        if (sharesElement) {
          postData.shares = sharesElement.textContent.trim();
        }
      }

      // Extract recent comments
      const commentElements = document.querySelectorAll(
        '[data-testid*="comment"], .comment, [role="article"]'
      );

      commentElements.forEach((commentElement, index) => {
        const commentAuthor = commentElement.querySelector(
          '[data-testid="comment-author"], .comment-author, a[role="link"]'
        );
        const commentContent = commentElement.querySelector(
          '[data-testid="comment-content"], .comment-content, [dir="auto"]'
        );
        const commentTime = commentElement.querySelector(
          '[data-testid="comment-timestamp"], .comment-timestamp, time'
        );

        if (commentAuthor && commentContent) {
          postData.comments.push({
            author: commentAuthor.textContent.trim(),
            content: commentContent.textContent.trim(),
            timestamp: commentTime ? commentTime.textContent.trim() : "",
            index: index + 1,
          });
        }
      });

      return postData;
    } catch (error) {
      console.error("Error extracting Facebook post content from DOM:", error);
      return null;
    }
  }

  // Function to fetch current Facebook post data from DOM
  async function fetchCurrentFacebookPost() {
    if (
      window.location.hostname !== "www.facebook.com" &&
      window.location.hostname !== "facebook.com" &&
      window.location.hostname !== "m.facebook.com"
    ) {
      return null;
    }

    try {
      const postData = getFacebookPostDataFromUrl(window.location.href);
      if (!postData) {
        return null;
      }

      // Wait a bit for Facebook to load the content
      await new Promise((resolve) => setTimeout(resolve, 2000));

      const content = extractFacebookPostContentFromDOM();
      if (!content) {
        return null;
      }

      const result = {
        success: true,
        ...postData,
        content,
      };

      return result;
    } catch (error) {
      console.error("Error fetching Facebook post from DOM:", error);
      return null;
    }
  }

  // Function to format Facebook post context for AI
  function formatFacebookContext(facebookData) {
    if (!facebookData || !facebookData.content) {
      return "";
    }

    const post = facebookData.content;

    let context = `\n\n=== FACEBOOK POST CONTEXT ===\n`;

    if (post.author) {
      context += `Post Author: ${post.author}\n`;
    }

    if (post.timestamp) {
      context += `Posted: ${post.timestamp}\n`;
    }

    if (post.likes) {
      context += `Likes: ${post.likes}\n`;
    }

    if (post.shares) {
      context += `Shares: ${post.shares}\n`;
    }

    context += `\nPOST CONTENT:\n${post.content}\n`;

    // Add comment context if we're replying to a comment
    if (post.isCommentReply && post.parentComment) {
      context += `\n=== COMMENT REPLY CONTEXT ===\n`;
      context += `⚠️ YOU ARE REPLYING TO A SPECIFIC COMMENT ⚠️\n`;
      context += `Replying to: ${post.parentComment.author}\n`;
      context += `Original Comment: ${post.parentComment.content}\n`;

      if (post.parentComment.timestamp) {
        context += `Posted: ${post.parentComment.timestamp}\n`;
      }

      if (post.parentComment.likes) {
        context += `Likes: ${post.parentComment.likes}\n`;
      }

      context += `\n💡 Write a reply that directly addresses ${post.parentComment.author}'s comment.\n`;
    }

    // Add recent comments context
    if (post.comments.length > 0) {
      context += `\nRECENT COMMENTS (${post.comments.length}):\n`;
      // Show last 5 comments for context
      const recentComments = post.comments.slice(-5);
      recentComments.forEach((comment) => {
        context += `\n--- Comment ${comment.index} by ${comment.author} ---\n`;
        context += `Content: ${comment.content}\n`;
        if (comment.timestamp) {
          context += `Time: ${comment.timestamp}\n`;
        }
      });
    }

    context += `\n=== END FACEBOOK CONTEXT ===\n\n`;

    return context;
  }

  // Function to get current Instagram post data from URL
  function getInstagramPostDataFromUrl(url) {
    const urlObj = new URL(url);
    if (
      urlObj.hostname === "www.instagram.com" ||
      urlObj.hostname === "instagram.com"
    ) {
      const pathParts = urlObj.pathname.split("/");
      // URL format: /p/POST_ID/ or /reel/POST_ID/
      if (
        pathParts.length >= 3 &&
        (pathParts[1] === "p" || pathParts[1] === "reel")
      ) {
        return {
          postId: pathParts[2],
          postType: pathParts[1], // 'p' for post, 'reel' for reel
          isPost: true,
        };
      }
    }
    return null;
  }

  // Function to extract Instagram post content from DOM
  function extractInstagramPostContentFromDOM() {
    try {
      const postData = {
        author: "",
        caption: "",
        hashtags: [],
        location: "",
        timestamp: "",
        likes: "",
        comments: [],
        isCommentReply: false,
        parentComment: null,
        postType: "post",
      };

      // Check if we're in a comment reply context
      const replyInput = document.querySelector(
        '[data-testid="comment-composer"], [aria-label*="Add a comment"], [placeholder*="Add a comment"], [contenteditable="true"][data-testid*="comment"]'
      );

      if (replyInput) {
        // Try to find the comment being replied to
        const commentThread = replyInput.closest(
          '[data-testid*="comment"], .comment, [role="article"]'
        );
        if (commentThread) {
          const parentCommentElement = commentThread.querySelector(
            '[data-testid*="comment"], .comment'
          );
          if (parentCommentElement) {
            const parentAuthor = parentCommentElement.querySelector(
              '[data-testid="comment-author"], .comment-author, a[role="link"]'
            );
            const parentContent = parentCommentElement.querySelector(
              '[data-testid="comment-content"], .comment-content, [dir="auto"]'
            );

            if (parentAuthor && parentContent) {
              postData.isCommentReply = true;
              postData.parentComment = {
                author: parentAuthor.textContent.trim(),
                content: parentContent.textContent.trim(),
                timestamp: "",
                likes: "",
              };

              // Extract timestamp and likes for parent comment
              const parentTime = parentCommentElement.querySelector(
                '[data-testid="comment-timestamp"], .comment-timestamp, time'
              );
              const parentLikes = parentCommentElement.querySelector(
                '[data-testid="comment-likes"], .comment-likes'
              );

              if (parentTime) {
                postData.parentComment.timestamp =
                  parentTime.textContent.trim();
              }
              if (parentLikes) {
                postData.parentComment.likes = parentLikes.textContent.trim();
              }
            }
          }
        }
      }

      // Extract post author
      const authorElement = document.querySelector(
        '[data-testid="post-author"], .post-author, a[role="link"], [data-testid*="author"], header a'
      );
      if (authorElement) {
        postData.author = authorElement.textContent.trim();
      }

      // Extract post caption/description
      const captionElement = document.querySelector(
        '[data-testid="post-caption"], .post-caption, [data-testid*="caption"], article [dir="auto"]'
      );
      if (captionElement) {
        postData.caption = captionElement.textContent.trim();
        // Limit caption length
        postData.caption = postData.caption.substring(0, 1000);

        // Extract hashtags from caption
        const hashtagMatches = postData.caption.match(/#\w+/g);
        if (hashtagMatches) {
          postData.hashtags = hashtagMatches;
        }
      }

      // Extract location if available
      const locationElement = document.querySelector(
        '[data-testid="post-location"], .post-location, a[href*="/locations/"]'
      );
      if (locationElement) {
        postData.location = locationElement.textContent.trim();
      }

      // Extract post timestamp
      const timeElement = document.querySelector(
        '[data-testid="post-timestamp"], .post-timestamp, time, [data-testid*="timestamp"]'
      );
      if (timeElement) {
        postData.timestamp = timeElement.textContent.trim();
      }

      // Extract likes count
      const likesElement = document.querySelector(
        '[data-testid="post-likes"], .post-likes, [data-testid*="likes"], button[data-testid*="like"]'
      );
      if (likesElement) {
        postData.likes = likesElement.textContent.trim();
      }

      // Determine post type (post vs reel)
      const reelIndicator = document.querySelector(
        '[data-testid="reel-indicator"], .reel-indicator, [data-testid*="reel"]'
      );
      if (reelIndicator) {
        postData.postType = "reel";
      }

      // Extract recent comments
      const commentElements = document.querySelectorAll(
        '[data-testid*="comment"], .comment, [role="article"]'
      );

      commentElements.forEach((commentElement, index) => {
        const commentAuthor = commentElement.querySelector(
          '[data-testid="comment-author"], .comment-author, a[role="link"]'
        );
        const commentContent = commentElement.querySelector(
          '[data-testid="comment-content"], .comment-content, [dir="auto"]'
        );
        const commentTime = commentElement.querySelector(
          '[data-testid="comment-timestamp"], .comment-timestamp, time'
        );

        if (commentAuthor && commentContent) {
          postData.comments.push({
            author: commentAuthor.textContent.trim(),
            content: commentContent.textContent.trim(),
            timestamp: commentTime ? commentTime.textContent.trim() : "",
            index: index + 1,
          });
        }
      });

      return postData;
    } catch (error) {
      console.error("Error extracting Instagram post content from DOM:", error);
      return null;
    }
  }

  // Function to fetch current Instagram post data from DOM
  async function fetchCurrentInstagramPost() {
    if (
      window.location.hostname !== "www.instagram.com" &&
      window.location.hostname !== "instagram.com"
    ) {
      return null;
    }

    try {
      const postData = getInstagramPostDataFromUrl(window.location.href);
      if (!postData) {
        return null;
      }

      // Wait a bit for Instagram to load the content
      await new Promise((resolve) => setTimeout(resolve, 2000));

      const content = extractInstagramPostContentFromDOM();
      if (!content) {
        return null;
      }

      const result = {
        success: true,
        ...postData,
        content,
      };

      return result;
    } catch (error) {
      console.error("Error fetching Instagram post from DOM:", error);
      return null;
    }
  }

  // Function to format Instagram post context for AI
  function formatInstagramContext(instagramData) {
    if (!instagramData || !instagramData.content) {
      return "";
    }

    const post = instagramData.content;

    let context = `\n\n=== INSTAGRAM POST CONTEXT ===\n`;
    context += `Post Type: ${post.postType === "reel" ? "Reel" : "Post"}\n`;

    if (post.author) {
      context += `Author: ${post.author}\n`;
    }

    if (post.location) {
      context += `Location: ${post.location}\n`;
    }

    if (post.timestamp) {
      context += `Posted: ${post.timestamp}\n`;
    }

    if (post.likes) {
      context += `Likes: ${post.likes}\n`;
    }

    context += `\nPOST CAPTION:\n${post.caption}\n`;

    if (post.hashtags.length > 0) {
      context += `\nHASHTAGS: ${post.hashtags.join(" ")}\n`;
    }

    // Add comment context if we're replying to a comment
    if (post.isCommentReply && post.parentComment) {
      context += `\n=== COMMENT REPLY CONTEXT ===\n`;
      context += `⚠️ YOU ARE REPLYING TO A SPECIFIC COMMENT ⚠️\n`;
      context += `Replying to: ${post.parentComment.author}\n`;
      context += `Original Comment: ${post.parentComment.content}\n`;

      if (post.parentComment.timestamp) {
        context += `Posted: ${post.parentComment.timestamp}\n`;
      }

      if (post.parentComment.likes) {
        context += `Likes: ${post.parentComment.likes}\n`;
      }

      context += `\n💡 Write a reply that directly addresses ${post.parentComment.author}'s comment.\n`;
    }

    // Add recent comments context
    if (post.comments.length > 0) {
      context += `\nRECENT COMMENTS (${post.comments.length}):\n`;
      // Show last 5 comments for context
      const recentComments = post.comments.slice(-5);
      recentComments.forEach((comment) => {
        context += `\n--- Comment ${comment.index} by ${comment.author} ---\n`;
        context += `Content: ${comment.content}\n`;
        if (comment.timestamp) {
          context += `Time: ${comment.timestamp}\n`;
        }
      });
    }

    context += `\n=== END INSTAGRAM CONTEXT ===\n\n`;

    return context;
  }

  // Function to get current Quora question data from URL
  function getQuoraQuestionDataFromUrl(url) {
    const urlObj = new URL(url);
    if (
      urlObj.hostname === "www.quora.com" ||
      urlObj.hostname === "quora.com"
    ) {
      const pathParts = urlObj.pathname.split("/");
      // URL format: /question/QUESTION_ID/QUESTION-TITLE or /QUESTION-TITLE
      if (pathParts.length >= 2) {
        return {
          questionId: pathParts[pathParts.length - 1] || pathParts[1],
          questionSlug: pathParts.join("/"),
          isQuestion: true,
        };
      }
    }
    return null;
  }

  // Function to extract Quora question content from DOM
  function extractQuoraQuestionContentFromDOM() {
    try {
      const questionData = {
        title: "",
        details: "",
        topics: [],
        answers: [],
        answerCount: "",
        followers: "",
        isAnswerMode: false,
        parentAnswer: null,
        questionAuthor: "",
      };

      // Check if we're in answer mode
      const answerInput = document.querySelector(
        '[data-testid="answer-composer"], [aria-label*="Write an answer"], [placeholder*="Write an answer"], [contenteditable="true"][data-testid*="answer"]'
      );

      if (answerInput) {
        questionData.isAnswerMode = true;
      }

      // Extract question title
      const titleElement = document.querySelector(
        '[data-testid="question-title"], .question-title, h1, .q-text, [data-testid*="title"]'
      );
      if (titleElement) {
        questionData.title = titleElement.textContent.trim();
      }

      // Extract question details/description
      const detailsElement = document.querySelector(
        '[data-testid="question-details"], .question-details, .q-details, [data-testid*="details"]'
      );
      if (detailsElement) {
        questionData.details = detailsElement.textContent.trim();
        // Limit details length
        questionData.details = questionData.details.substring(0, 1500);
      }

      // Extract question author
      const authorElement = document.querySelector(
        '[data-testid="question-author"], .question-author, .q-author, a[data-testid*="author"]'
      );
      if (authorElement) {
        questionData.questionAuthor = authorElement.textContent.trim();
      }

      // Extract topics/tags
      const topicElements = document.querySelectorAll(
        '[data-testid="topic-tag"], .topic-tag, .q-topic, [data-testid*="topic"]'
      );
      topicElements.forEach((topicElement) => {
        const topicText = topicElement.textContent.trim();
        if (topicText && !questionData.topics.includes(topicText)) {
          questionData.topics.push(topicText);
        }
      });

      // Extract answer count
      const answerCountElement = document.querySelector(
        '[data-testid="answer-count"], .answer-count, .q-answer-count, [data-testid*="answer-count"]'
      );
      if (answerCountElement) {
        questionData.answerCount = answerCountElement.textContent.trim();
      }

      // Extract followers count
      const followersElement = document.querySelector(
        '[data-testid="followers-count"], .followers-count, .q-followers, [data-testid*="followers"]'
      );
      if (followersElement) {
        questionData.followers = followersElement.textContent.trim();
      }

      // Extract existing answers
      const answerElements = document.querySelectorAll(
        '[data-testid*="answer"], .answer, [role="article"]'
      );

      answerElements.forEach((answerElement, index) => {
        const answerAuthor = answerElement.querySelector(
          '[data-testid="answer-author"], .answer-author, a[data-testid*="author"]'
        );
        const answerContent = answerElement.querySelector(
          '[data-testid="answer-content"], .answer-content, [data-testid*="content"]'
        );
        const answerTime = answerElement.querySelector(
          '[data-testid="answer-timestamp"], .answer-timestamp, time'
        );
        const answerUpvotes = answerElement.querySelector(
          '[data-testid="answer-upvotes"], .answer-upvotes, [data-testid*="upvotes"]'
        );

        if (answerAuthor && answerContent) {
          questionData.answers.push({
            author: answerAuthor.textContent.trim(),
            content: answerContent.textContent.trim().substring(0, 500),
            timestamp: answerTime ? answerTime.textContent.trim() : "",
            upvotes: answerUpvotes ? answerUpvotes.textContent.trim() : "",
            index: index + 1,
          });
        }
      });

      // Check if we're replying to a specific answer
      if (questionData.isAnswerMode) {
        const replyContext = document.querySelector(
          '[data-testid="reply-context"], .reply-context, [data-testid*="reply"]'
        );
        if (replyContext) {
          const parentAnswerAuthor = replyContext.querySelector(
            '[data-testid="answer-author"]'
          );
          const parentAnswerContent = replyContext.querySelector(
            '[data-testid="answer-content"]'
          );

          if (parentAnswerAuthor && parentAnswerContent) {
            questionData.parentAnswer = {
              author: parentAnswerAuthor.textContent.trim(),
              content: parentAnswerContent.textContent.trim().substring(0, 300),
              timestamp: "",
              upvotes: "",
            };
          }
        }
      }

      return questionData;
    } catch (error) {
      console.error("Error extracting Quora question content from DOM:", error);
      return null;
    }
  }

  // Function to fetch current Quora question data from DOM
  async function fetchCurrentQuoraQuestion() {
    if (
      window.location.hostname !== "www.quora.com" &&
      window.location.hostname !== "quora.com"
    ) {
      return null;
    }

    try {
      const questionData = getQuoraQuestionDataFromUrl(window.location.href);
      if (!questionData) {
        return null;
      }

      // Wait a bit for Quora to load the content
      await new Promise((resolve) => setTimeout(resolve, 2000));

      const content = extractQuoraQuestionContentFromDOM();
      if (!content) {
        return null;
      }

      const result = {
        success: true,
        ...questionData,
        content,
      };

      return result;
    } catch (error) {
      console.error("Error fetching Quora question from DOM:", error);
      return null;
    }
  }

  // Function to format Quora question context for AI
  function formatQuoraContext(quoraData) {
    if (!quoraData || !quoraData.content) {
      return "";
    }

    const question = quoraData.content;

    let context = `\n\n=== QUORA QUESTION CONTEXT ===\n`;

    if (question.questionAuthor) {
      context += `Asked by: ${question.questionAuthor}\n`;
    }

    if (question.answerCount) {
      context += `Answers: ${question.answerCount}\n`;
    }

    if (question.followers) {
      context += `Followers: ${question.followers}\n`;
    }

    if (question.topics.length > 0) {
      context += `Topics: ${question.topics.join(", ")}\n`;
    }

    context += `\nQUESTION TITLE:\n${question.title}\n`;

    if (question.details) {
      context += `\nQUESTION DETAILS:\n${question.details}\n`;
    }

    // Add answer context if we're replying to a specific answer
    if (question.isAnswerMode && question.parentAnswer) {
      context += `\n=== ANSWER REPLY CONTEXT ===\n`;
      context += `⚠️ YOU ARE REPLYING TO A SPECIFIC ANSWER ⚠️\n`;
      context += `Replying to: ${question.parentAnswer.author}\n`;
      context += `Original Answer: ${question.parentAnswer.content}\n`;

      if (question.parentAnswer.timestamp) {
        context += `Posted: ${question.parentAnswer.timestamp}\n`;
      }

      if (question.parentAnswer.upvotes) {
        context += `Upvotes: ${question.parentAnswer.upvotes}\n`;
      }

      context += `\n💡 Write a reply that directly addresses ${question.parentAnswer.author}'s answer.\n`;
    } else if (question.isAnswerMode) {
      context += `\n=== ANSWER MODE ===\n`;
      context += `📝 TASK: Write a comprehensive answer to this question.\n`;
      context += `💡 REQUIREMENTS:\n`;
      context += `- Provide a detailed, well-structured answer\n`;
      context += `- Use clear explanations and examples\n`;
      context += `- Consider the existing answers for context\n`;
      context += `- Make your answer valuable and informative\n`;
    }

    // Add existing answers context
    if (question.answers.length > 0) {
      context += `\nEXISTING ANSWERS (${question.answers.length}):\n`;
      // Show last 3 answers for context
      const recentAnswers = question.answers.slice(-3);
      recentAnswers.forEach((answer) => {
        context += `\n--- Answer ${answer.index} by ${answer.author} ---\n`;
        context += `Content: ${answer.content}\n`;
        if (answer.timestamp) {
          context += `Time: ${answer.timestamp}\n`;
        }
        if (answer.upvotes) {
          context += `Upvotes: ${answer.upvotes}\n`;
        }
      });
    }

    context += `\n=== END QUORA CONTEXT ===\n\n`;

    return context;
  }

  // Function to extract current user's name from Gmail
  function getCurrentUserName() {
    try {
      // Method 1: Try to get from Gmail account menu
      const accountButton = document.querySelector(
        '[aria-label*="Google Account"], [aria-label*="Account"], .gb_d, .gb_e'
      );
      if (accountButton) {
        const accountText =
          accountButton.getAttribute("aria-label") || accountButton.textContent;
        if (accountText) {
          // Extract name from aria-label like "Google Account: John Doe (john.doe@gmail.com)"
          const nameMatch = accountText.match(
            /(?:Google Account:\s*)?([^(]+?)(?:\s*\([^)]+\))?$/
          );
          if (nameMatch) {
            return nameMatch[1].trim();
          }
        }
      }

      // Method 2: Try to get from profile picture alt text
      const profilePic = document.querySelector(
        'img[alt*="Profile"], img[alt*="Account"], .gb_A img'
      );
      if (profilePic) {
        const altText = profilePic.getAttribute("alt");
        if (altText && !altText.includes("Profile picture")) {
          return altText.trim();
        }
      }

      // Method 3: Try to get from compose button or other Gmail elements
      const composeButton = document.querySelector(
        '[aria-label*="Compose"], .T-I'
      );
      if (composeButton) {
        const composeText = composeButton.getAttribute("aria-label");
        if (composeText && composeText.includes("Compose")) {
          // Look for user info in nearby elements
          const userInfo = document.querySelector(".gb_d, .gb_e, [data-email]");
          if (userInfo) {
            const userText =
              userInfo.textContent || userInfo.getAttribute("data-email");
            if (userText) {
              const emailMatch = userText.match(/^([^@]+)/);
              if (emailMatch) {
                return emailMatch[1]
                  .replace(/[._]/g, " ")
                  .replace(/\b\w/g, (l) => l.toUpperCase());
              }
            }
          }
        }
      }

      // console.log('Could not extract user name from Gmail');
      return null;
    } catch (error) {
      console.error("Error extracting user name:", error);
      return null;
    }
  }

  // Function to extract email content from Gmail DOM
  function extractEmailContentFromDOM() {
    const emails = [];

    try {
      // Find all email messages in the current thread
      const messageElements = document.querySelectorAll(
        '[role="main"] [data-message-id]'
      );
      // console.log('Found message elements:', messageElements.length);

      messageElements.forEach((element, index) => {
        const messageId = element.getAttribute("data-message-id");

        // Extract subject
        const subjectElement = element.querySelector(
          "[data-thread-perm-id] h2, [data-thread-perm-id] h3, .hP"
        );
        const subject = subjectElement
          ? subjectElement.textContent.trim()
          : "No Subject";

        // Extract sender
        const senderElement = element.querySelector(".gD, .zF, [email]");
        const from = senderElement
          ? senderElement.textContent.trim()
          : "Unknown Sender";

        // Extract date
        const dateElement = element.querySelector('.xW, .xY, [title*=","]');
        const date = dateElement ? dateElement.textContent.trim() : "";

        // Extract email body
        const bodyElement = element.querySelector(
          '.a3s, .adn, [role="main"] .ii'
        );
        let body = "";
        if (bodyElement) {
          body = bodyElement.textContent.trim();
          // Clean up the text
          body = body.replace(/\s+/g, " ").substring(0, 1000);
        }

        // Extract snippet as fallback
        const snippetElement = element.querySelector(".y2");
        const snippet = snippetElement ? snippetElement.textContent.trim() : "";

        emails.push({
          id: messageId || `msg_${index}`,
          subject,
          from,
          date,
          body: body || snippet,
          snippet,
        });

        // console.log(`Extracted email ${index + 1}:`, { subject, from, body: body.substring(0, 100) + '...' });
      });

      // If no messages found with data-message-id, try alternative selectors
      if (emails.length === 0) {
        // console.log('No messages found with data-message-id, trying alternative selectors...');

        // Try to find email content in the main area
        const mainContent = document.querySelector('[role="main"]');
        if (mainContent) {
          const textContent = mainContent.textContent.trim();
          if (textContent) {
            emails.push({
              id: "current_thread",
              subject: "Current Email Thread",
              from: "Gmail",
              date: new Date().toLocaleString(),
              body: textContent.substring(0, 1000),
              snippet: textContent.substring(0, 200),
            });
          }
        }
      }
    } catch (error) {
      console.error("Error extracting email content from DOM:", error);
    }

    // console.log('Extracted emails from DOM:', emails);
    return emails;
  }

  // Function to fetch current Gmail thread data from DOM
  async function fetchCurrentGmailThread() {
    if (window.location.hostname !== "mail.google.com") {
      return null;
    }

    try {
      // console.log("Current URL on Gmail:", window.location.href);

      const threadId = getThreadIdFromUrl(window.location.href);
      if (!threadId) {
        // console.log('No thread ID found in URL');
        return null;
      }

      // console.log('Extracting thread data for ID:', threadId);

      // Wait a bit for Gmail to load the content
      await new Promise((resolve) => setTimeout(resolve, 1000));

      const emails = extractEmailContentFromDOM();

      const result = {
        success: true,
        threadId,
        emails,
        threadSubject: emails[0]?.subject || "No Subject",
      };

      // console.log('Gmail thread data from DOM:', result);
      return result;
    } catch (error) {
      console.error("Error fetching Gmail thread from DOM:", error);
      return null;
    }
  }

  // Function to format Gmail thread data for AI context
  function formatGmailContext(threadData) {
    if (!threadData || !threadData.emails) {
      return "";
    }

    let context = `\n\n=== GMAIL THREAD CONTEXT ===\n`;
    context += `Thread Subject: ${threadData.threadSubject}\n`;
    context += `Thread ID: ${threadData.threadId}\n`;
    context += `Number of emails: ${threadData.emails.length}\n\n`;

    context += `EMAIL HISTORY:\n`;
    threadData.emails.forEach((email, index) => {
      context += `\n--- Email ${index + 1} ---\n`;
      context += `From: ${email.from}\n`;
      context += `Date: ${email.date}\n`;
      context += `Subject: ${email.subject}\n`;
      context += `Content: ${email.body || email.snippet}\n`;
    });

    context += `\n=== END GMAIL CONTEXT ===\n\n`;

    return context;
  }

  // Gather context from current page
  async function gatherContexts() {
    const hostname = window.location.hostname;
    let contexts = "";

    try {
      if (hostname === "mail.google.com") {
        const threadData = await fetchCurrentGmailThread();
        if (threadData) {
          contexts += formatGmailContext(threadData);
        }
      } else if (hostname === "github.com") {
        const issueData = await fetchCurrentGitHubIssue();
        if (issueData) {
          contexts += formatGitHubContext(issueData);
        }
      } else if (hostname === "app.slack.com") {
        const conversationData = await fetchCurrentSlackConversation();
        if (conversationData) {
          contexts += formatSlackContext(conversationData);
        }
      } else if (hostname === "www.youtube.com" || hostname === "youtube.com") {
        const youtubeData = await fetchCurrentYouTubeData();
        if (youtubeData) {
          contexts += formatYouTubeContext(youtubeData);
        }
      } else if (hostname === "www.facebook.com" || hostname === "facebook.com" || hostname === "m.facebook.com") {
        const facebookData = await fetchCurrentFacebookPost();
        if (facebookData) {
          contexts += formatFacebookContext(facebookData);
        }
      } else if (hostname === "www.instagram.com" || hostname === "instagram.com") {
        const instagramData = await fetchCurrentInstagramPost();
        if (instagramData) {
          contexts += formatInstagramContext(instagramData);
        }
      } else if (hostname === "www.quora.com" || hostname === "quora.com") {
        const quoraData = await fetchCurrentQuoraQuestion();
        if (quoraData) {
          contexts += formatQuoraContext(quoraData);
        }
      }
    } catch (error) {
      console.error("Error gathering contexts:", error);
    }

    return contexts;
  }

  // Handle Puck commands
  async function handlePuckCommand(text, targetElement) {
    if (isProcessing || !text.includes("puck:")) {
      return false;
    }

    const command = text.match(/puck:(.*?);/);
    if (!command) {
      return false;
    }

    const userPrompt = command[1].trim();
    isProcessing = true;

    // Show loading state
    const loaderText = "⏳ Generating...";
    const originalContent = targetElement.value !== undefined ? targetElement.value : targetElement.innerText;
    const contentWithLoader = originalContent.replace(/puck:.*?;/, loaderText);
    updateElementContent(targetElement, contentWithLoader);

    // Gather context based on current site
    const contexts = await gatherContexts();
    const userName = getCurrentUserName();
    const userContext = userName ? `\nCurrent User: ${userName}` : "";

    const finalPrompt = `You are a helpful AI assistant. Provide ONLY the direct answer to the user's request. Do NOT include any explanations, examples, or additional context.

RULES:
- Give ONLY the direct answer
- No explanations or examples
- No "The formula is..." or "You can use..." type phrases
- Just the raw answer itself
- Do NOT include quotation marks around the answer — just the plain text
- Assume the user wants to use the result in raw form

User request: "${userPrompt}"${userContext}${contexts}`;

    // Call OpenAI API
    fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${API_KEY}`,
      },
      body: JSON.stringify({
        model: "gpt-4",
        messages: [{ role: "user", content: finalPrompt }],
        temperature: 0.7,
        max_tokens: 500,
      }),
    })
      .then(response => response.json())
      .then(data => {
        const contentText = data.choices?.[0]?.message?.content || "✅ Generated content (but no text returned)";
        const finalContent = contentWithLoader.replace(loaderText, contentText.trim());
        updateElementContent(targetElement, finalContent);
        isProcessing = false;
      })
      .catch(error => {
        console.error("Error from OpenAI API:", error);
        const finalContent = contentWithLoader.replace(loaderText, "❌ Failed to generate content");
        updateElementContent(targetElement, finalContent);
        isProcessing = false;
      });

    return true;
  }

  // Update element content safely
  function updateElementContent(element, newContent) {
    try {
      if (element.value !== undefined) {
        // Input/textarea elements
        element.value = newContent;
        element.focus();
        element.setSelectionRange(newContent.length, newContent.length);
        element.dispatchEvent(new Event("input", { bubbles: true }));
        element.dispatchEvent(new Event("change", { bubbles: true }));
      } else if (element.contentEditable === "true") {
        // Contenteditable elements
        element.innerText = newContent;
        element.focus();
        
        const range = document.createRange();
        const selection = window.getSelection();
        range.selectNodeContents(element);
        range.collapse(false);
        selection.removeAllRanges();
        selection.addRange(range);
        
        element.dispatchEvent(new Event("input", { bubbles: true }));
      } else {
        // Fallback
        element.textContent = newContent;
      }
    } catch (error) {
      console.error("Error updating element content:", error);
      isProcessing = false;
    }
  }

  // Debounced input handler
  function debouncedInputHandler(e) {
    clearTimeout(inputTimeout);
    inputTimeout = setTimeout(async () => {
      const target = e.target;
      if (target.tagName === "TEXTAREA" || target.tagName === "INPUT" || target.isContentEditable) {
        const text = target.value || target.innerText || target.textContent;
        await handlePuckCommand(text, target);
      }
    }, 100);
  }

  // Event listeners
  document.addEventListener("input", debouncedInputHandler, true);

  document.addEventListener("keydown", (e) => {
    if (e.key === ";" && !isProcessing) {
      setTimeout(async () => {
        const target = e.target;
        if (target.tagName === "TEXTAREA" || target.tagName === "INPUT" || target.isContentEditable) {
          const text = target.value || target.innerText || target.textContent;
          await handlePuckCommand(text, target);
        }
      }, 10);
    }
  }, true);

  // Handle dynamic content changes
  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      if (mutation.type === "childList") {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === Node.ELEMENT_NODE) {
            const inputs = node.querySelectorAll('input, textarea, [contenteditable="true"]');
            inputs.forEach((input) => {
              if (!input.hasAttribute("data-puck-initialized")) {
                input.setAttribute("data-puck-initialized", "true");
              }
            });
          }
        });
      }
    });
  });

  observer.observe(document.body, { childList: true, subtree: true });

  // Initialize existing elements
  document.addEventListener("DOMContentLoaded", () => {
    const inputs = document.querySelectorAll('input, textarea, [contenteditable="true"]');
    inputs.forEach((input) => {
      input.setAttribute("data-puck-initialized", "true");
    });
  });
})();
