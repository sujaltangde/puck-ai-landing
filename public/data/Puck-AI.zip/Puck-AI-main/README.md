# Puck - AI-Powered Browser Extension

Puck is a powerful browser extension that brings AI assistance directly into your web browsing experience. Simply type `puck: your question;` in any text input field, and watch as AI generates contextual responses based on the current webpage you're viewing.

## 🚀 What Puck Can Do

Puck intelligently analyzes the current webpage context and provides AI-generated responses for:

### 📧 **Gmail**
- Compose emails with context from the current email thread
- Generate professional responses based on conversation history
- Extract thread information, subjects, and participant details

### 💻 **GitHub**
- Write issue descriptions and comments with full context
- Generate pull request descriptions
- Respond to issues with knowledge of labels, assignees, and existing comments

### 💬 **Slack**
- Compose messages with conversation context
- Generate responses based on recent messages and participants
- Work in channels, DMs, and threads

### 📺 **YouTube**
- Write comments with video context
- Access video title, description, and engagement metrics

### 📷 **Instagram**
- Write captions and comments with post context
- Generate replies to existing comments
- Access post details, hashtags, and engagement

### ❓ **Quora**
- Write answers with full question context
- Generate responses to existing answers
- Access question details, topics, and answer history

### 🌐 **Any Website**
Puck works on **any website** with text input fields! While it provides enhanced context for the platforms above, you can use it anywhere you need AI assistance.

## 🎯 How to Use Puck

1. **Navigate** to any website with a text input field
2. **Type** your prompt in the format: `puck:your question here;`
3. **Press Enter** or continue typing - Puck will automatically detect the command
4. **Wait** for the AI to generate a contextual response
5. **Review** and edit the generated content as needed

### Example Usage:
```
puck:Write a professional email response to this customer inquiry;
puck:Generate a comment about this video;
puck:Write a reply to this GitHub issue;
puck:Create a caption for this Instagram post;
```

## 📦 Installation

### Step 1: Download the Extension
1. Download the Puck extension files (zip file)
2. Extract the files to a folder on your computer

### Step 2: Add Your OpenAI API Key
1. Open `api_key.js` in any text editor
2. Find the line: `export const OPEN_AI_API_KEY = "paste your api key here";`
3. Replace the text with your own OpenAI API key
4. Save the file

### Step 3: Install in Your Browser

#### Chrome/Edge/Brave:
1. Open your browser and go to `chrome://extensions/`
2. Enable "Developer mode" (toggle in top right)
3. Click "Load unpacked"
4. Select the folder containing the Puck extension files
5. The extension is now installed and active!

#### Firefox:
1. Open Firefox and go to `about:debugging`
2. Click "This Firefox" tab
3. Click "Load Temporary Add-on"
4. Select the `manifest.json` file from the Puck folder
5. The extension is now installed and active!

## 🔧 Requirements

- **OpenAI API Key**: Get one from [OpenAI Platform](https://platform.openai.com/api-keys)
- **Modern Browser**: Chrome, Firefox, Edge, or Brave
- **Internet Connection**: Required for AI API calls

## 💡 Tips for Best Results

- **Be Specific**: The more specific your prompt, the better the AI response
- **Use Context**: Puck automatically includes webpage context, so reference it in your prompts
- **Edit After**: Always review and edit generated content before sending
- **Try Different Prompts**: Experiment with different ways to phrase your requests

## 🔒 Privacy & Security

- Your API key is stored locally in the extension
- All AI requests go directly to OpenAI's servers
- No data is stored or transmitted to third parties
- Webpage context is only sent to OpenAI when you use the `puck:` command

## 🛠️ Technical Details

- **Model**: Uses GPT-4 for high-quality responses
- **Context Extraction**: Automatically analyzes webpage DOM for relevant information
- **Cross-Platform**: Works on any website with text input fields
- **Real-time**: Processes commands as you type

## 🆘 Troubleshooting

**Extension not working?**
- Check that your OpenAI API key is correctly set in `content.js`
- Ensure you have sufficient OpenAI API credits
- Try refreshing the webpage and typing the command again

**No response generated?**
- Verify your internet connection
- Check that you're using the correct format: `puck:your question;`
- Ensure the text field is active and focused

**Context not being captured?**
- Wait a moment for the page to fully load
- Try refreshing the page
- Some dynamic websites may require a brief delay

## 📄 License

This project is open source and available under the MIT License.

---

**Ready to supercharge your browsing experience? Install Puck and start typing `puck:your questions;` anywhere on the web!** 🚀 